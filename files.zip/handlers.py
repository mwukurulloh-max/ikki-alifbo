"""Telegram update handlerlari: buyruqlar, menyu tanlash, konvertatsiya, xatolar."""

from __future__ import annotations

import logging
from io import BytesIO

from telegram import Update
from telegram.ext import ContextTypes

from config import FILE_THRESHOLD, SAFE_CHUNK_LENGTH
from converter import auto_convert, convert_cyrillic_to_latin, convert_latin_to_cyrillic
from keyboards import (
    BTN_AUTO,
    BTN_CYR_TO_LAT,
    BTN_HELP,
    BTN_LAT_TO_CYR,
    after_result_keyboard,
    main_menu_keyboard,
)

logger = logging.getLogger(__name__)

# Foydalanuvchi tanlagan rejimlar uchun ichki kalitlar.
MODE_LAT2CYR: str = "lat2cyr"
MODE_CYR2LAT: str = "cyr2lat"
MODE_AUTO: str = "auto"

MODE_LABELS: dict[str, str] = {
    MODE_LAT2CYR: BTN_LAT_TO_CYR,
    MODE_CYR2LAT: BTN_CYR_TO_LAT,
    MODE_AUTO: BTN_AUTO,
}

WEBSITE_URL: str = "https://mwukurulloh-max.github.io/ikki-alifbo/"

WELCOME_TEXT: str = (
    "Assalomu alaykum! 👋\n\n"
    "Men o'zbek tilidagi matnlarni *lotin* va *kirill* yozuvlari o'rtasida "
    "konvertatsiya qiluvchi botman.\n\n"
    "Quyidagi menyudan kerakli rejimni tanlang, so'ng menga matn yuboring:\n\n"
    f"🌐 Veb-saytimiz ham bor: {WEBSITE_URL}"
)

HELP_TEXT: str = (
    "*Bot qanday ishlaydi:*\n\n"
    "1️⃣ Menyudan rejimni tanlang:\n"
    "   • 🔤 Lotin -> Kirill\n"
    "   • 🔡 Kirill -> Lotin\n"
    "   • 🔄 Avtomatik aniqlash (yozuvni o'zi aniqlaydi)\n\n"
    "2️⃣ Menga matn yuboring — men uni tanlangan rejimda konvertatsiya qilib beraman.\n\n"
    "3️⃣ Juda uzun matn yuborsangiz, natijani .txt fayl sifatida qaytaraman.\n\n"
    "*Eslatma:* ingliz tilidagi so'zlar, raqamlar, tinish belgilari va emoji "
    "o'zgarishsiz qoladi. Rejimni istalgan vaqt menyudan qayta tanlashingiz mumkin.\n\n"
    "Buyruqlar: /start — botni qayta ishga tushirish, /help — shu yordam xabari.\n\n"
    f"🌐 Xuddi shu konvertatsiya veb-saytda ham mavjud: {WEBSITE_URL}"
)

EMPTY_TEXT_WARNING: str = (
    "Matn bo'sh ko'rinadi. Iltimos, konvertatsiya qilish uchun biror matn yuboring."
)
NO_MODE_WARNING: str = (
    "Avval menyudan rejimni tanlang, keyin matn yuboring. /start buyrug'ini bosing."
)


async def start_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """/start buyrug'ini ishlaydi: foydalanuvchini salomlaydi va menyuni ko'rsatadi."""
    context.user_data.pop("mode", None)
    await update.message.reply_text(
        WELCOME_TEXT, parse_mode="Markdown", reply_markup=main_menu_keyboard()
    )


async def help_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """/help buyrug'ini ishlaydi: bot qanday ishlashini tushuntiradi."""
    await update.message.reply_text(HELP_TEXT, parse_mode="Markdown")


async def menu_button_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Asosiy reply-klaviatura tugmalari bosilganda rejimni o'rnatadi."""
    text = update.message.text

    if text == BTN_HELP:
        await help_handler(update, context)
        return

    mode_by_text = {
        BTN_LAT_TO_CYR: MODE_LAT2CYR,
        BTN_CYR_TO_LAT: MODE_CYR2LAT,
        BTN_AUTO: MODE_AUTO,
    }
    mode = mode_by_text.get(text)
    if mode is None:
        return

    context.user_data["mode"] = mode
    await update.message.reply_text(
        f"{MODE_LABELS[mode]} rejimi tanlandi.\n\nEndi matningizni yuboring 📝"
    )


async def _send_result(update: Update, context: ContextTypes.DEFAULT_TYPE, result: str) -> None:
    """Konvertatsiya natijasini yuboradi: uzun bo'lsa fayl, aks holda matn bo'laklari.

    Args:
        update: Telegramdan kelgan yangilanish.
        context: Handler konteksti.
        result: Foydalanuvchiga yuboriladigan konvertatsiya qilingan matn.
    """
    if len(result) > FILE_THRESHOLD:
        buffer = BytesIO(result.encode("utf-8"))
        buffer.name = "natija.txt"
        await update.message.reply_document(
            document=buffer,
            filename="natija.txt",
            caption="Natija uzun bo'lgani uchun fayl sifatida yubordim 📄",
            reply_markup=after_result_keyboard(),
        )
        return

    chunks = [
        result[i : i + SAFE_CHUNK_LENGTH] for i in range(0, len(result), SAFE_CHUNK_LENGTH)
    ] or [""]

    for i, chunk in enumerate(chunks):
        is_last = i == len(chunks) - 1
        markup = after_result_keyboard() if is_last else None
        # Kod bloki ichida yuborish natijani "ajratilgan matn" sifatida ko'rsatadi
        # va nusxalashni osonlashtiradi.
        await update.message.reply_text(
            f"```\n{chunk}\n```", parse_mode="Markdown", reply_markup=markup
        )


async def text_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Kelgan matnni joriy tanlangan rejimga muvofiq konvertatsiya qiladi."""
    try:
        mode = context.user_data.get("mode")
        if not mode:
            await update.message.reply_text(NO_MODE_WARNING, reply_markup=main_menu_keyboard())
            return

        text = update.message.text or ""
        if not text.strip():
            await update.message.reply_text(EMPTY_TEXT_WARNING)
            return

        if mode == MODE_LAT2CYR:
            result = convert_latin_to_cyrillic(text)
        elif mode == MODE_CYR2LAT:
            result = convert_cyrillic_to_latin(text)
        else:
            result = auto_convert(text)

        await _send_result(update, context, result)

    except Exception:  # noqa: BLE001 - bot hech qachon qulab tushmasligi kerak
        logger.exception("Konvertatsiya vaqtida xato yuz berdi")
        await update.message.reply_text(
            "Kechirasiz, konvertatsiya vaqtida kutilmagan xatolik yuz berdi. "
            "Iltimos, qaytadan urinib ko'ring."
        )


async def callback_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Natijadan keyingi inline tugmalar (Davom etish / Bosh menyu) bosilishini ishlaydi."""
    query = update.callback_query
    await query.answer()

    if query.data == "menu":
        context.user_data.pop("mode", None)
        await query.message.reply_text("Bosh menyu:", reply_markup=main_menu_keyboard())
    elif query.data == "continue":
        mode = context.user_data.get("mode")
        if mode:
            await query.message.reply_text(
                f"{MODE_LABELS[mode]} rejimida davom etamiz. Matn yuboring 📝"
            )
        else:
            await query.message.reply_text(NO_MODE_WARNING, reply_markup=main_menu_keyboard())


async def error_handler(update: object, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Global xato ishlovchisi: xatoni log qiladi va botni hech qachon qulatmaydi."""
    logger.error("Update %s ni ishlashda xato: %s", update, context.error, exc_info=context.error)

    if isinstance(update, Update) and update.effective_message:
        try:
            await update.effective_message.reply_text(
                "Kechirasiz, kutilmagan xatolik yuz berdi. Iltimos, qaytadan urinib ko'ring."
            )
        except Exception:  # noqa: BLE001
            logger.exception("Xato haqidagi xabarni foydalanuvchiga yuborib bo'lmadi")
